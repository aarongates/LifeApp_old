// public/js/controllers/TutorialCtrl.js
angular.module('TutorialCtrl', []).controller('TutorialController', function($scope) {

    $scope.tagline = 'This is from the controller';

});

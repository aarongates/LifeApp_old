// public/js/app.js
angular.module('sampleApp', ['ngRoute',
                             'appRoutes',
                             'MainCtrl',
                             'TutorialCtrl',
                             'TutorialService']);

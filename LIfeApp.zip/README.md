# LifeApp

Good Mongo Reference: http://docs.mongodb.org/v3.0/reference/sql-comparison/ <br />
Good Angular Reference: http://www.cheatography.com/proloser/cheat-sheets/angularjs/
Nodemon Site: http://nodemon.io
Good tutorial reference: http://scotch.io
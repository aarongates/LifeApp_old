//this should be the config/db.js file
    module.exports = {
        url : 'mongodb://gates739:phoebefender@ds033133.mongolab.com:33133/lifedb'
    }